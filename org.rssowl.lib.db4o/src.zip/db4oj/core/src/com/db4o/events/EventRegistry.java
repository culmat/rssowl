/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.events;

/**
 * Provides a way to register event handlers for specific {@link ObjectContainer} events.
 * 
 * @see EventRegistryFactory
 */
public interface EventRegistry {
	
	/**
	 * Receives {@link QueryEventArgs}.
	 * 
	 * @sharpen.event QueryEventArgs
	 * @return
	 */
	public Event4 queryStarted();
	
	/**
	 * Receives {@link QueryEventArgs}.
	 *
	 * @sharpen.event QueryEventArgs
	 * @return
	 */
	public Event4 queryFinished();

	/**
	 * Receives {@link CancellableObjectEventArgs}.
	 * 
	 * @sharpen.event CancellableObjectEventArgs
	 * @return
	 */
	public Event4 creating();

	/**
	 * Receives {@link CancellableObjectEventArgs}.
	 *
	 * @sharpen.event CancellableObjectEventArgs
	 * @return
	 */
	public Event4 activating();
	
	/**
	 * Receives {@link CancellableObjectEventArgs}
	 *
	 * @sharpen.event CancellableObjectEventArgs
	 * @return
	 */
	public Event4 updating();
	
	/**
	 * Receives {@link CancellableObjectEventArgs}
	 * 
	 * @sharpen.event CancellableObjectEventArgs
	 * @return
	 */
	public Event4 deleting();
	
	/**
	 * Receives {@link CancellableObjectEventArgs}
	 * 
	 * @sharpen.event CancellableObjectEventArgs
	 * @return
	 */
	public Event4 deactivating();

	/**
	 * Receives {@link ObjectEventArgs}.
	 * 
	 * @sharpen.event ObjectEventArgs
	 * @return
	 */
	public Event4 activated();

	/**
	 * Receives {@link ObjectEventArgs}.
	 * 
	 * @sharpen.event ObjectEventArgs
	 * @return
	 */
	public Event4 created();

	/**
	 * Receives {@link ObjectEventArgs}
	 * 
	 * @sharpen.event ObjectEventArgs
	 * @return
	 */
	public Event4 updated();

	/**
	 * Receives {@link ObjectEventArgs}
	 * 
	 * @sharpen.event ObjectEventArgs
	 * @return
	 */
	public Event4 deleted();

	/**
	 * Receives {@link ObjectEventArgs}
	 * 
	 * @sharpen.event ObjectEventArgs
	 * @return
	 */
	public Event4 deactivated();
}
