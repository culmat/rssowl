/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.defragment;

import com.db4o.*;
import com.db4o.inside.btree.*;

/**
 * Second step in the defragmenting process: Fills in target file pointer slots, copies
 * content slots from source to target and triggers ID remapping therein by calling the
 * appropriate yap/marshaller defrag() implementations. During the process, the actual address
 * mappings for the content slots are registered for use with string indices.
 * 
 * @exclude
 */
final class SecondPassCommand implements PassCommand {

	public void processClass(DefragContextImpl context, final YapClass yapClass, int id,final int classIndexID) throws CorruptionException {
		if(context.mappedID(id,-1)==-1) {
			System.err.println("MAPPING NOT FOUND: "+id);
		}
		ReaderPair.processCopy(context, id, new SlotCopyHandler() {
			public void processCopy(ReaderPair readers) throws CorruptionException {
				yapClass.defragClass(readers, classIndexID);
			}
		});
	}

	public void processObjectSlot(DefragContextImpl context, final YapClass yapClass, int id, boolean registerAddresses) throws CorruptionException {
		ReaderPair.processCopy(context, id, new SlotCopyHandler() {
			public void processCopy(ReaderPair readers) {
				YapClass.defragObject(readers);
			}
		},registerAddresses);
	}

	public void processClassCollection(DefragContextImpl context) throws CorruptionException {
		ReaderPair.processCopy(context, context.sourceClassCollectionID(), new SlotCopyHandler() {
			public void processCopy(ReaderPair readers) {
				YapClassCollection.defrag(readers);
			}
		});
	}

	public void processBTree(final DefragContextImpl context, BTree btree) throws CorruptionException {
		btree.defragBTree(context);
	}

	public void flush(DefragContextImpl context) {
	}
}